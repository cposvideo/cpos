from typing import Set
from src.core.dag.graph import DAG


class PartialRegenerator:
    """
    Determines which parts of the DAG must be re-run
    when a specific node changes.
    """

    def affected_subgraph(self, dag: DAG, changed_node: str) -> Set[str]:
        affected = set()

        def walk(node_id: str):
            if node_id in affected:
                return
            affected.add(node_id)
            for nid, node in dag.nodes.items():
                if node_id in node.dependencies:
                    walk(nid)

        walk(changed_node)
        return affected
